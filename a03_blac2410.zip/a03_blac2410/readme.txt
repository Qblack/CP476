Name: Quinton Black
ID: 100532410
Email: blac2410@mylaurier.ca
Assignment_ID: A3
Homework statement: I claim that the enclosed submission is my individual work

Hours: hours spent on this assignment 26

URL:  (i.e., the URL of your main assignment homepage of this course)

Check list and evaluation

[  10/10/] Q1a:
[  10/10/] Q1b:

[  20/20/] Q2:

[  10/10/] Q3a:
[  20/20/] Q3b:
[  10/10/] Q3c:

[ 10 /10/] Q4a:
[  20/20/] Q4b:
[  10/10/] Q4c:


[  20/20/] Q5


[  140/140/] Total: