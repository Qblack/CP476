<body>
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="jumbotron center"><h1>Welcome to my mobile site</h1></div>
                <iframe style="align-content: center" width="640" height="390" src="https://www.youtube.com/embed/wky5H1xC6-I" frameborder="0" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</body>


