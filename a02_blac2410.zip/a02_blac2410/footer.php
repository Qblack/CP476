<div class="footer">
    <div class="container">
        <div class='col-xs-12 text-center'>
            <hr>
            &copy; Quinton Black 2015
            <a class='link-nav' href="index.php">Home</a> &nbsp;
            <a class='link-nav' href="portal.html">Portal</a> &nbsp;
        </div>
    </div>
</div>