Name: Quinton Black
ID: 100532410
Email:CP476A2
Homework statement: I claim that the enclosed submission is my individual work
Hours: 10 hours spent on this assignment (estimated 10 hours)

URL:  http://hopper.wlu.ca/~blac2410/a02_blac2410/portal.html

Self-evaluation:

[ 10/10/]Q1.1
[ 20/20/]Q1.2

[ 20/20/]Q2

[ 10/10/]Q3.1
[ 20/20/]Q3.2

[ 80/80/]Total:

